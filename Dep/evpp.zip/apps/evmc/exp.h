#pragma once

#include <evpp/exp.h>

#ifdef H_OS_WINDOWS
H_LINK_LIB("evmc_static")
#endif

