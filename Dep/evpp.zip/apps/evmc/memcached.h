#pragma once
#include "memcache_client_pool.h"
#include "memcache_client_serial.h"
